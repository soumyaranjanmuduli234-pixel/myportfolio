﻿Tally Modern v1.0 — Complete Accounting & Inventory Software
============================================================

Requirements: Windows 10/11 (No Python installation needed)
Login: SOUMYA / Soumya@7890

How to Run:
1. Extract this folder
2. Double-click TallyModern.exe
3. Login with SOUMYA / Soumya@7890
4. Select or create a company

Features:
- Sales, Purchase, Payment, Receipt, Contra, Journal vouchers
- Sales Return / Purchase Return (F10)
- Stock Transfer between godowns (F11)
- Customer Udhaar Khata (Party Ledger)
- Customer Price List (Retail/Wholesale/MRP auto rate)
- Customer Purchase History (with PDF export)
- Sales Analytics (Bar, Line, Pie Charts)
- Top Selling Items Report
- Profit & Loss Statement
- Dashboard Widgets (This Month, This Year, Udhaar, Top Items)
- Day Book Search (Ctrl+F)
- Multiple Print Copies (Original/Duplicate/Triplicate)
- GST Billing with CGST/SGST/IGST
- Company Logo on Invoice
- Cash Drawer Management
- Modern Custom Dialogs (keyboard Y/N support)
- Settings (Theme, Font Size, Password)
- PDF saved to Desktop or App folder
- 100% Offline - No internet needed

Keyboard Shortcuts:
  F2  = Change Date
  F3  = Company Info
  F4  = Contra
  F5  = Payment
  F6  = Receipt
  F7  = Journal
  F8  = Sales Invoice
  F9  = Purchase Invoice
  F10 = Sales/Purchase Return
  F11 = Stock Transfer
  C   = Create Master
  A   = Alter Master
  V   = Voucher Menu
  S   = Stock Report
  K   = Day Book
  R   = Reports
  Ctrl+A = Save only
  Ctrl+P = Save + Print + Close
  Ctrl+F = Search Day Book
  Ctrl+Shift+R = Refresh
  ESC = Close/Quit

Tech Stack: Python 3.10, Tkinter, SQLite, ReportLab, Matplotlib

© 2026. All rights reserved.
